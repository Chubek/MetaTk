#include "SSAVM.hpp"
namespace metavm { namespace library {
const Profile& SSAVM_profile() {
 static const Profile profile = {"SSAVM","ssa","issa-subset","Instruction-indexed results; CEN edge selection; PHI/PFE commit; persistent arrays",&SSAVM_example_module};
 return profile;
}
} }
