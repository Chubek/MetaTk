#include "ISSA.hpp"
#include "MetaVM.h"
#include <optional>
namespace metavm { namespace machines {
ISSA::Result ISSA::run(const std::vector<Instruction>&p,const std::vector<int64_t>&args,uint64_t fuel) {
    if(p.empty()||p.size()>1000000)throw std::runtime_error("ISSA program size invalid");
    for(const auto&in:p) {
        size_t n=0;
        switch(in.op) {
        case Op::constant:case Op::argument:case Op::jump:case Op::pfe:n=0;break;
        case Op::ret:case Op::array:case Op::length:n=1;break;
        case Op::set:n=3;break;
        case Op::phi:if(in.operands.empty())throw std::runtime_error("empty phi");n=in.operands.size();break;
        default:n=2;break;
        }
        if(in.operands.size()!=n)throw std::runtime_error("ISSA operand arity");
        for(auto r:in.operands)if(r>=p.size())throw std::runtime_error("ISSA operand out of range");
        if((in.op==Op::jump||in.op==Op::branch_equal||in.op==Op::branch_le)&&in.target>=p.size())
            throw std::runtime_error("ISSA target out of range");
    }
    std::vector<std::optional<Value>> rr(p.size()),pending(p.size());
    std::vector<size_t> staged;
    size_t pc=0,cen=0,allocated_elements=0; uint64_t steps=0;
    auto charge=[&](size_t n){if(n>16777216-allocated_elements)throw std::runtime_error("ISSA allocation budget");allocated_elements+=n;};
    auto value=[&](size_t r)->Value { if(!rr[r])throw std::runtime_error("ISSA undefined result");return *rr[r]; };
    auto scalar=[&](size_t r)->int64_t {
        Value v=value(r);if(!std::holds_alternative<int64_t>(v))throw std::runtime_error("ISSA expected scalar");return std::get<int64_t>(v);
    };
    auto arr=[&](size_t r)->Array {
        Value v=value(r);if(!std::holds_alternative<Array>(v))throw std::runtime_error("ISSA expected array");return std::get<Array>(v);
    };
    for(;;) {
        if(steps==fuel)throw std::runtime_error("ISSA fuel exhausted");
        ++steps;
        if(pc>=p.size())throw std::runtime_error("ISSA fell off program");
        const auto&in=p[pc]; const auto&o=in.operands; size_t next=pc+1;
        if(!staged.empty()&&in.op!=Op::phi&&in.op!=Op::pfe)throw std::runtime_error("ISSA phi group needs pfe");
        switch(in.op) {
        case Op::constant:rr[pc]=in.immediate;break;
        case Op::argument:
            if(in.immediate<0||uint64_t(in.immediate)>=args.size())throw std::runtime_error("ISSA argument index");
            rr[pc]=args[size_t(in.immediate)];break;
        case Op::add:case Op::sub:case Op::mul:case Op::div: {
            int64_t result; mvm_opcode op=in.op==Op::add?MVM_OP_ADD:in.op==Op::sub?MVM_OP_SUB:in.op==Op::mul?MVM_OP_MUL:MVM_OP_DIV;
            if(mvm_integer_eval(op,scalar(o[0]),scalar(o[1]),&result)!=MVM_OK)throw std::runtime_error("ISSA integer arithmetic trap");
            rr[pc]=result;break;
        }
        case Op::equal:rr[pc]=int64_t(scalar(o[0])==scalar(o[1]));break;
        case Op::less_equal:rr[pc]=int64_t(scalar(o[0])<=scalar(o[1]));break;
        case Op::jump:next=in.target;cen=in.edge;break;
        case Op::branch_equal:case Op::branch_le:
            if(in.op==Op::branch_equal?scalar(o[0])==scalar(o[1]):scalar(o[0])<=scalar(o[1])) {next=in.target;cen=in.edge;}else cen=0;
            break;
        case Op::phi:
            if(cen>=o.size())throw std::runtime_error("ISSA edge exceeds phi arity");
            pending[pc]=value(o[cen]);staged.push_back(pc);break;
        case Op::pfe:
            for(auto r:staged){rr[r]=std::move(pending[r]);pending[r].reset();}staged.clear();cen=0;break;
        case Op::array: {
            auto n=scalar(o[0]);if(n<0||n>1000000)throw std::runtime_error("ISSA array allocation limit");
            charge(size_t(n));
            rr[pc]=Array(std::make_shared<const std::vector<int64_t>>(size_t(n),0));break;
        }
        case Op::length:rr[pc]=int64_t(arr(o[0])->size());break;
        case Op::get:case Op::set: {
            auto a=arr(o[0]);auto idx=scalar(o[1]);if(idx<0||uint64_t(idx)>=a->size())throw std::runtime_error("ISSA array bounds");
            if(in.op==Op::get)rr[pc]=(*a)[size_t(idx)];
            else {charge(a->size());auto copy=std::make_shared<std::vector<int64_t>>(*a);(*copy)[size_t(idx)]=scalar(o[2]);rr[pc]=Array(copy);}
            break;
        }
        case Op::ret:return {value(o[0]),steps};
        }
        pc=next;
    }
}
}}
