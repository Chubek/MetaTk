#pragma once
#include <cstdint>
#include <memory>
#include <stdexcept>
#include <variant>
#include <vector>
namespace metavm { namespace machines {
/* Executable ISSA subset derived from TR 03-19 sections 2.1–2.4.
 * Result register = instruction index. Branches carry a CFG edge number.
 * PHIs stage values until PFE, preventing sequential-copy corruption.
 * Arrays are immutable versions (copy on update), not the paper's optimized
 * reference-count/access ordering implementation. */
class ISSA {
public:
    using Array=std::shared_ptr<const std::vector<int64_t>>;
    using Value=std::variant<int64_t,Array>;
    enum class Op { constant, argument, add, sub, mul, div, equal, less_equal,
                    jump, branch_equal, branch_le, phi, pfe, array, get, set, length, ret };
    struct Instruction {
        Op op; std::vector<size_t> operands;
        int64_t immediate=0; size_t target=0,edge=0;
    };
    struct Result { Value value; uint64_t steps; };
    static Result run(const std::vector<Instruction>& program,
                      const std::vector<int64_t>& args={},uint64_t fuel=1000000);
};
}}
