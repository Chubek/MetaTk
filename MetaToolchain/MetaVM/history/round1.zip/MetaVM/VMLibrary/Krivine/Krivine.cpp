#include "Krivine.hpp"
namespace metavm { namespace library {
const Profile& Krivine_profile() {
 static const Profile profile = {"Krivine","closure","catalog-only","Call-by-name lambda calculus abstract machine",&Krivine_example_module};
 return profile;
}
} }
