#pragma once
#include "Krivine.h"
#include "../Library.hpp"
namespace metavm { namespace library { const Profile& Krivine_profile(); } }
