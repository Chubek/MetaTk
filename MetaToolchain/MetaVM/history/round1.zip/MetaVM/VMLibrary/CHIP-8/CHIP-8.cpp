#include "CHIP-8.hpp"
namespace metavm { namespace library {
const Profile& CHIP_8_profile() {
 static const Profile profile = {"CHIP-8","register","classic-opcode-interpreter","CHIP-8 classic 4 KiB, 16 byte registers, 64x32 display",&CHIP_8_example_module};
 return profile;
}
} }
