#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <vector>
namespace metavm { namespace machines {
class Chip8 {
public:
    enum class Status { running, waiting, invalid_opcode, bounds, stack_overflow, stack_underflow };
    struct Quirks { bool shift_uses_y=false, increment_i=false, jump_uses_x=false, clip_sprites=false; } quirks;
    std::array<uint8_t,4096> memory{};
    std::array<uint8_t,16> v{};
    std::array<uint16_t,16> stack{};
    std::array<bool,16> keys{};
    std::array<uint8_t,64*32> display{};
    uint16_t pc=0x200,i=0;
    uint8_t sp=0,delay=0,sound=0;
    uint32_t random_state=0x12345678;
    Chip8();
    bool load(const std::vector<uint8_t>& rom);
    Status step();
    void tick_60hz() { if(delay) --delay; if(sound) --sound; }
};
}}
