#pragma once
#include "SECD.h"
#include "../Library.hpp"
namespace metavm { namespace library { const Profile& SECD_profile(); } }
