#include "SECD.hpp"
namespace metavm { namespace library {
const Profile& SECD_profile() {
 static const Profile profile = {"SECD","closure","catalog-only","Stack, environment, control, dump",&SECD_example_module};
 return profile;
}
} }
