#pragma once
#include "MetaML.hpp"
#include "Builder.hpp"
#include <limits>
namespace vmweave {
/* A fresh Session per translation. No stdlib or file imports are required.
 * This evaluates trusted build-time MetaML, not untrusted guest bytecode.
 * Host callbacks capture owned shared state so no callback dangles. */
inline metavm::Module compile(const std::string& source, size_t max_bytes=16*1024*1024) {
    auto builder=std::make_shared<Builder>(max_bytes);
    metaml::Session session;
    session.register_primitive("vm_emit", [builder](std::string line) -> void {builder->emit(line);});
    session.register_primitive("vm_function", [builder](std::string n,int64_t a,int64_t r) -> void {builder->function(n,a,r);});
    session.register_primitive("vm_const", [builder](int64_t r,int64_t v) -> void {builder->constant(r,v);});
    session.register_primitive("vm_binary", [builder](std::string op,int64_t d,int64_t l,int64_t r) -> void {builder->binary(op,d,l,r);});
    session.register_primitive("vm_label", [builder](std::string n) -> void {builder->label(n);});
    session.register_primitive("vm_jump", [builder](std::string n) -> void {builder->jump(n);});
    session.register_primitive("vm_jump_false", [builder](int64_t r,std::string n) -> void {builder->jump_false(r,n);});
    session.register_primitive("vm_return", [builder](int64_t r) -> void {builder->ret(r);});
    session.register_primitive("vm_end", [builder]() -> void {builder->end();});
    auto evaluated=session.eval(source,"<VMWeave>");
    if(evaluated.is_err()) throw std::runtime_error("MetaML evaluation failed; no module published");
    return builder->finish();
}
}
