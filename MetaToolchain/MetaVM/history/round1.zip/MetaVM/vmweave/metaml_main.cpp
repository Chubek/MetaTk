#include "MetaMLAdapter.hpp"
#include <fstream>
#include <iostream>
#include <iterator>
int main(int argc,char**argv) {
    try {
        if(argc!=3) { std::cerr<<"usage: vmweave-metaml INPUT.vmweave OUTPUT.mvmb\n"; return 2; }
        std::ifstream in(argv[1],std::ios::binary);
        if(!in) throw std::runtime_error("cannot open VMWeave source");
        std::string src((std::istreambuf_iterator<char>(in)),{});
        auto module=vmweave::compile(src); module.save(argv[2]); return 0;
    } catch(const std::exception&e) { std::cerr<<e.what()<<'\n'; return 1; }
}
