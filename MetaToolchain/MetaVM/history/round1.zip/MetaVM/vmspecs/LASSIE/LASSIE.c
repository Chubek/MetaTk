#include "LASSIE.h"
mvm_status legacy_LASSIE_example(mvm_module **out,mvm_error *error) { (void)error; if(out)*out=0; return MVM_NOT_FOUND; }
