# Observed validation

Tested on Linux x86-64 with GCC C11/C++17. No CMake, pkg-config, libdrm
headers/device, matching DSLtk.hpp, or complete MetaTeX dependency graph was
available. These observations describe this edition, not full guest conformance.

## Passed

- Dependency-free fallback compile and link of the C11 Machinery core, VMWeave
  CLI, all 49 C/C++ catalog profiles, native implementations and legacy adapters.
  New build uses `-Wall -Wextra -Wpedantic -Werror`.
- Existing Machinery regression suite: **5,056 checks passed**.
- Existing C++11 ownership wrapper test.
- Original factorial example under bytecode and threaded engines: **3628800**.
- All 49 portable module factories verify and return **42** under both engines.
  DRMVM's example also verifies its host-bound drawing effect.
- CHIP-8 arithmetic carry, shifts/quirk switch, BCD, drawing/XOR collision,
  subroutine return, key wait/resumption, timers and memory/stack/ROM bounds.
- SSAVM paper figure-5 Fibonacci loop: **55** with staged PHI/PFE semantics;
  persistent array versions, invalid operands, malformed PHI group,
  undefined register, array bounds and fuel traps.
- JVM integer expression/local arithmetic: **42**; backward-branch loop: **5**;
  malformed input, branch alignment, undefined local, divide-zero and fuel traps.
- FORTH colon word execution: **42**; stack words, signed true value and
  stack/arithmetic/recursion-fuel traps.
- DRMVM XRGB masking, clipped rectangles, dimensions, host binding and execution.
- Typed VMWeave builder, identifier/register/opcode validation, source limits,
  unfinished function rejection, module finalization and execution.
- C emitter output compiled and linked by the real C compiler; factory module
  verification, invalid identifier rejection and binary round trip.
- Final line-wrapped C-emitter output compiled with warnings treated as errors.
- All 49 profile specifications checked for current schema properties,
  unique identities, manifest agreement and required file references.
- Native integration tests also passed with `-O2 -DNDEBUG` (checks remain active).
- Python build/generation/validation scripts passed syntax compilation.
- AddressSanitizer + UndefinedBehaviorSanitizer: Machinery suite, C++ wrapper,
  native/catalog integration, both factorial engines, emitted-C factory and
  serialized module execution passed with `ASAN_OPTIONS=detect_leaks=0`.

## Limitations

LeakSanitizer could not inspect `/proc` in this environment and terminated before
leak analysis. Leak detection was disabled for the sanitizer execution; **no
leak-check pass is claimed**. A runner lost its executable bit on relinking;
restoring it allowed the remaining sanitized stages to pass. The fallback build
now sets the executable owner bit after successful links.

The optional MetaML adapter, VMDesc/MetaTeX adapter and libdrm allocation/upload
branch have not been compiled or run. No fake dependency headers were used to
claim validation. CMake configuration/build/install paths are provided but were
not exercised because CMake is absent. The fallback build is the observed path.

Portable catalog tests are not tests of the corresponding historical ISA.
Forty-four native guest runtimes remain unimplemented. The five native subsets
lack full external image loaders and platform runtimes. CHIP-8 uses direct ROM
loading with classic instructions; no external compatibility ROM suite was run.
The file `docs/COVERAGE.md` and each `.vmspc` record the distinction explicitly.

No complete architecture-to-native-backend generator, JIT, differential guest
conformance suite, GPU presentation/modesetting path, or full multi-runtime
implementation is claimed. See AGENTS.md for refinement priorities.
