# Machine coverage

Portable examples run on Machinery. Native support is separate. No machine has a complete external runtime/image loader.

| Machine | Architecture | Native coverage |
|---|---|---|
| ALEX | unspecified | catalog-only |
| ART | runtime | catalog-only |
| AVM2 | stack | catalog-only |
| B-Code | unspecified | catalog-only |
| BCPL | stack | catalog-only |
| BEAM | register | catalog-only |
| C-Machine | unspecified | catalog-only |
| CAM | closure | catalog-only |
| CESK | closure | catalog-only |
| CHIP-8 | register | classic-opcode-interpreter |
| CLR | stack | catalog-only |
| CPython | stack | catalog-only |
| ConcurrentML | runtime | catalog-only |
| DRMVM | graphics | graphics-subset |
| DVI | document | catalog-only |
| Dalvik | register | catalog-only |
| Dart | runtime | catalog-only |
| Dis | register | catalog-only |
| FAM | unspecified | catalog-only |
| FORTH | stack | integer-word-subset |
| FUL | unspecified | catalog-only |
| G-Code | motion | catalog-only |
| Harrison | unspecified | catalog-only |
| IKL | unspecified | catalog-only |
| JSCore | runtime | catalog-only |
| JVM | stack | integer-method-subset |
| Krivine | closure | catalog-only |
| LuaVM | register | catalog-only |
| Lucide | unspecified | catalog-only |
| Monty | unspecified | catalog-only |
| MoscowML | closure | catalog-only |
| P-Code | stack | catalog-only |
| P4 | unspecified | catalog-only |
| ParrotVM | register | catalog-only |
| PostScript | stack | catalog-only |
| Prol | unspecified | catalog-only |
| SCUMM | script | catalog-only |
| SECD | closure | catalog-only |
| SOM | object | catalog-only |
| SSAVM | ssa | issa-subset |
| Self | object | catalog-only |
| Smaltalk-80 | object | catalog-only |
| TAMMY | unspecified | catalog-only |
| V8 | runtime | catalog-only |
| WAM | logic | catalog-only |
| WASM | stack | catalog-only |
| YARV | stack | catalog-only |
| Z-Machine | unspecified | catalog-only |
| Zand | unspecified | catalog-only |
