# Supplied inputs and optional dependencies

The existing Machinery implementation was retained from MetaVM.zip. MetaML.hpp
here is the exact supplied MetaML(1).hpp. No substitute DSLtk implementation is
included. Build the MetaML embedding only with the matching C++20 DSLtk header.
The authoring adapter registers typed primitives on metaml::Session; no external
MetaML standard library is required for the bundled authoring examples.

VMDesc targets the actual metatex::Engine API in the supplied MetaTeX.zio ZIP
(the extension does not change its ZIP format). Extract that original archive
and configure its MetaDoc/MetaTeX directory as the external source dependency.
It is not duplicated in this package. That project also needs MetaVect, DSLtk,
MetaML and the optional/external components described by its CMake configuration.
Retain and follow its own AGENTS.md when refining that dependency.

Original input SHA-256 hashes:

```
MetaVM.zip
bf36dabf211256b78026390ed55fe33c6aeb9d36047931a9bc6586d5a39005e2
MetaML(1).hpp (vendored here as MetaML.hpp)
1477e56be681541983785eedd5c7eb30e8fad02f77f878a90ba390f7d2326b9a
MetaTeX.zio
75d1113afe7a278a6665fa3c6fa72f3e7e0aea9e242a2c69c1adad02c02e9334
vm-ssa.pdf (preserved in docs/)
dd19acd2467eb6542093e41afde5d0a68f1f296bcd031b2f26d3def2227c54ee
```

The standalone build has no third-party runtime dependency. The optional Linux
DRM backend needs libdrm headers/library and a caller-authorized KMS device fd.
No matching headers, library or GPU were available for hardware validation.

Supplied artifacts carry their original provenance; this package does not infer
or add a license grant to third-party inputs.
