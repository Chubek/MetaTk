# MetaVM implementation and refinement contract

MetaVM is part of MetaTks / MetaToolchain. Preserve these boundaries:
Machinery is the execution substrate; VMWeave is a **MetaML embedding** used to
construct verified Machinery modules; VMDesc is a **MetaTeX embedding** used to
document machine definitions. Native guest runtimes live in VMLibrary.

## Read first

1. `README.md`, `docs/COVERAGE.md`, and `MANIFEST.yaml` for actual coverage.
2. `Machinery/README.md`, `Machinery/VERIFICATION.md`, public headers and tests.
3. `vmweave/Builder.hpp`, `vmweave/MetaMLAdapter.hpp`, and `VMDesc/MetaTeXAdapter.hpp`.
4. The machine's `.vmspc`, `.vmdesc`, native API header and regression tests.
5. `docs/vm-ssa.pdf` for SSAVM, especially sections 2.1–2.4 and appendix A.
6. `third_party/DEPENDENCIES.md` before enabling external integrations.

## What is implemented

The supplied Machinery core is retained. It has a C11 register machine,
module construction/verification, text assembly, versioned binary serialization,
GC-managed objects, execution limits, two dispatch engines and C host imports.
New code adds:

- A VMWeave C bootstrap assembly API, CLI and verified-module-to-C emitter.
- A tested C++17 authoring builder, and a real optional MetaML C++20 embedding
  adapter. The MetaML adapter is implemented but **not compiled or executed in
  this environment** because matching `DSLtk.hpp` is missing.
- A real VMDesc MetaTeX command-registration adapter, likewise **unvalidated**
  until the supplied MetaTeX project and its dependencies can be built.
- A catalog of 49 machine identities, paired C/C++ APIs, portable examples,
  MetaML authoring files, machine specifications and documentation sources.
- Native executable subsets for CHIP-8, SSAVM, JVM integer Code arrays, FORTH
  integer words and DRMVM graphics host imports. See the exact native headers.
- Legacy vmspecs adapters with explicit example names; unmatched names return
  `MVM_NOT_FOUND` rather than silently masquerading as another machine.

**Forty-four catalog entries do not implement native guest execution.** Their
C factories build explicitly named portable Machinery examples. A result of 42
from those examples proves the factory/build pipeline, not platform support.
Do not claim JVM .class, DEX, WASM modules, Ruby/Python bytecode, BEAM files,
Smalltalk images, or any other full historical runtime is implemented.

## Nonnegotiable engineering rules

- Never replace an unknown/native opcode with NOP, zero, success or a generic
  arithmetic implementation. Reject it with a diagnostic. No empty function
  bodies or success-only mock implementations.
- Pin the guest format/version before adding a loader. Several catalog names
  are runtimes, languages or private/ambiguous names, not published ISAs.
  Harrison, FUL, IKL, Monty, ALEX, Lucide, Zand, TAMMY and other unspecified
  profiles need authoritative sources; do not infer an ISA from their names.
- Keep `catalog-only`, native-subset coverage and full format compatibility
  distinct. Update specifications and coverage docs when behavior changes.
- Preserve the original `Smaltalk-80` directory spelling for compatibility.
  A correctly spelled alias is acceptable; do not silently rename public files.
- Do not modify or replace MetaML's parser with a lookalike. Use
  `metaml::Session::register_primitive` and evaluate the actual language.
- Do not parse VMDesc as a separate home-grown TeX dialect. Register commands
  on `metatex::Engine`; let MetaTeX own expansion and output devices.
- Treat MetaML authoring code as trusted build-time code. Guest instruction
  budgets do not sandbox arbitrary MetaML evaluation, imports or host effects.
- Preserve the C11 API and C++11 Machinery wrapper. New catalog code is C++17;
  MetaML/MetaTeX integration is C++20. Keep their dependencies optional.
- All public C headers must work in C and C++. Define symbols once; do not
  compile a legacy alias and a native implementation with colliding names.
- Module factories return owned modules; callers destroy them. Do not retain
  borrowed instruction views across module mutation. Registered host callback
  state must outlive its VM. Do not reenter the same running VM.
- Use defined arithmetic and explicit guest widths. Machinery wraps i64;
  JVM int operations wrap i32; CHIP-8 arithmetic wraps u8. Do not introduce
  signed-overflow UB. Division and shift edge cases need regression tests.
- Bound code, stack, frames, heap and instruction counts independently. A fuel
  limit alone does not cap allocation. ISSA currently has a cumulative budget
  of 16,777,216 array elements and a per-array bound of 1,000,000.
- `tools/generate_catalog.py` owns descriptors, example C factories, metadata
  headers/translation units and compatibility adapters. Change the generator
  for persistent catalog edits. It intentionally leaves native implementation
  files such as `Chip8.cpp`, `ISSA.cpp` and `Graphics.cpp` alone.
- Do not edit generated `.c` to imply native execution. Native implementations
  have separate APIs. Convert generation to native semantics only alongside
  a tested definition lowering pipeline.

## SSAVM semantic contract

Result register identity is the static instruction index. Branches carry an
explicit CEN (CFG edge number). PHI selects an operand using CEN and stages its
value; PFE commits the entire PHI group simultaneously and resets CEN. Reading
an undefined register traps. Figure 5's Fibonacci loop is a mandatory regression:
sequential PHI writes corrupt its old-value dependency.

Arrays have immutable versions: SET returns a copy, old versions remain intact.
This preserves the useful operational property but does not reproduce the
paper's optimized array access ordering/reference-count representation. The
implementation is a direct C++ interpreter of an ISSA subset, not a full SafeTSA
implementation or a textual `.ssa` reader. Keep that distinction visible.

## DRMVM semantic contract

DRMVM uses Machinery `drm_clear` and `drm_rect` native imports to operate on an
XRGB8888 host-owned surface. A compositor/renderer owns presentation. The
software path is the deterministic test backend. The optional libdrm path owns
a duplicate of a caller-provided KMS fd, GEM dumb allocation and mmap, releasing
them in reverse order. It does not acquire DRM master or change CRTC state.

Never guess a device, display, connector or privileged fd. Implement atomic
modesetting, explicit synchronization, DMA-BUF and format negotiation as separate
capabilities with injected host resources and hardware tests. Track pixel endian
assumptions before extending beyond little-endian XRGB8888. Current hardware
backend is source-complete for allocation/upload but uncompiled and untested here.
Binding the two imports is sequential; on a partial bind failure discard the VM
before retrying. The current host registry has no rollback/unregister operation.

## Required validation

Dependency-free fallback (available in the implementation environment):

```sh
make test
make sanitize
# In restricted environments where LeakSanitizer cannot inspect /proc:
ASAN_OPTIONS=detect_leaks=0 make sanitize
```

CMake build, when CMake >= 3.18 is installed:

```sh
cmake -S . -B out -DCMAKE_BUILD_TYPE=Debug -DMETAVM_TEST_CPP=ON
cmake --build out -j
ctest --test-dir out --output-on-failure
```

Optional real integrations must be tested before labeling them validated:

```sh
cmake -S . -B out-meta -DMETAVM_ENABLE_METAML=ON \
  -DMETAVM_DSLTK_INCLUDE_DIR=/path/to/matching/dsltk
cmake --build out-meta --target vmweave-metaml
out-meta/vmweave-metaml vmweave/factorial.vmweave factorial.mvmb
out-meta/Machinery/metavm-run factorial.mvmb
# Expected result: 3628800
```

VMDesc requires `metatex_core` in a parent project or
`METAVM_METATEX_SOURCE_DIR` with the supplied MetaTeX project's full dependencies.
libdrm requires `METAVM_ENABLE_LIBDRM=ON`, pkg-config and libdrm development files.
Never substitute stub headers to claim either integration works.

Tests must retain the 5,056 Machinery checks, original wrapper/example tests,
49 factory/example checks under both engines, generated C compile/link test,
binary round trip, and native semantic/trap regressions. Tests must also pass
with optimized builds and `NDEBUG`; the integration CHECK macro is unconditional.
For native support add exact guest bytes/programs, expected effects, malformed
input, branch bounds, overflow, allocation bounds and exhaustion cases.

## Prioritized refinement work

1. Supply the matching DSLtk dependency and compile the exact MetaML header.
   Run every `.vmweave`, compare serialized modules to the `.mvm` companion,
   test meta-programming (a MetaML function emitting a loop), retain full MetaML
   diagnostics/source spans and add evaluation/resource limits.
2. Build the supplied MetaTeX dependency graph, run all `.vmdesc` sources, test
   handlers with nested arguments and render HTML/PDF via its existing devices.
3. Move VMWeave from portable module authoring to versioned instruction/state
   definitions with decoding masks, custom operations, resource declarations and
   native backend generation. The present catalog/native bodies are **not**
   generated architecture implementations. Add a typed definition IR first;
   preserve the current assembly bootstrap for bootstrapping and tests.
4. Add SSAVM textual assembly, more instruction types, function calls, dominance
   and definition checks, explicit heap accounting, and differential tests against
   the paper's appendix programs. Refine arrays only while preserving versions.
5. Add a CHIP-8 ROM compatibility suite and explicit VIP/CHIP-48 quirk presets.
   Fx0A currently accepts an already-held key; edge/release behavior is not modeled.
   SCHIP/XO-CHIP, audio synthesis and display scheduling remain absent.
6. Refine DRMVM with C registry transactions or documented per-import binding,
   host-authorized presentation, real GPU integration tests and synchronization.
7. Add real versioned guest decoders to the catalog one machine at a time. JVM
   currently runs only integer Code arrays; FORTH has whole-input dictionary
   construction, not the interactive standard interpreter/compiler. Add loaders,
   object models, closures, exceptions, GC and schedulers where each ISA requires.
8. Extend CMake package install/export to include VMWeave/catalog tools and add
   Windows/macOS CI. Current installation exports Machinery only. CMake itself
   was unavailable during this implementation; the fallback build is verified.
9. Replace broad catalog compilation with per-machine selectable targets as
   implementations grow. Add schema validation and catalog regeneration CI.

## Delivery discipline

Read `docs/VALIDATION.md` for the last observed results and limitations. Exclude
build artifacts from release archives. Retain original dependency provenance.
Describe actual coverage and remaining work plainly; never call the entire
multi-runtime library complete or production-ready on the basis of these tests.
